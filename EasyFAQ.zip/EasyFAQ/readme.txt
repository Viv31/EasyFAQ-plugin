== EasyFAQ  ==
Contributors: vaibhav31gangrade
Donate link: 
Tags: FAQ,FAQ Shortcode,FAQ Plugin
Requires at least: 4.6
Tested up to: 5.5
Stable tag: 5.2
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://example.com/

== Description ==
Plugin for making FAQ page by just pasting shortcode [EFAQ question = "" answer = ""] here in place of question and answer you can place your data and copy shortcode as much as time and use.

== How to Use ==

After Installing paste [EFAQ question = "" answer = ""] and pass your data in question and answer fields and paste in your page.

== Requirements ==
It can run on any wordpress version.

== Frequently Asked Questions ==

= How exactly EasyFAQ works? =
  It takes two parameter question and its answer and create a card like toggle and shows data accordingly.


 == Changelog == 
 = 1.1 =
* A change since the previous version.

 == Upgrade Notice ==

 = 1.1 =
This version fixes a security related bug.Upgrade immediately.

 = 1.0 =
EasyFAQ with various options.



== Screenshots ==
This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).

2. This is the second screen shot
